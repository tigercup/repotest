#!/bin/bash

chown -R sanchez:sanchez /home/sanchez
chown -R morty:morty /var/tmp/morty/
chown -R beth:beth /home/beth/
chown -R jerry:jerry /tmp/jerry/
chown -R summer:summer /home/summer/

echo "sanchez        ALL=(ALL:ALL)   NOPASSWD:ALL" >> /etc/sudoers
